<?php
class MahasiswaController extends BaseController {
    private const NIM_LENGTH = 9;

    private Mahasiswa $model;

    public function __construct() {
        $this->model = new Mahasiswa();
    }

    // GET /mahasiswa  atau  GET /mahasiswa?id=1
    public function index($id = null): void {
        if ($id !== null && $id !== '') {
            $data = $this->model->find($this->requireId($id));
            if (!$data) {
                Response::json(404, false, 'Data tidak ditemukan');
            }
            Response::json(200, true, 'Data berhasil diambil', $data);
        }

        Response::json(200, true, 'Data berhasil diambil', $this->model->getAll());
    }

    // POST /mahasiswa
    public function store(): void {
        $data = $this->clean($this->readJson());

        try {
            $id = $this->model->create($data);
        } catch (DomainException $e) {
            Response::json(409, false, $e->getMessage());
        }

        Response::json(201, true, 'Data berhasil ditambahkan', ['id' => (int) $id]);
    }

    // PUT /mahasiswa?id=1
    public function update($id = null): void {
        $id = $this->requireId($id);

        if (!$this->model->find($id)) {
            Response::json(404, false, 'Data tidak ditemukan');
        }

        $data = $this->clean($this->readJson());

        try {
            $this->model->update($id, $data);
        } catch (DomainException $e) {
            Response::json(409, false, $e->getMessage());
        }

        Response::json(200, true, 'Data berhasil diperbarui');
    }

    // DELETE /mahasiswa?id=1
    public function destroy($id = null): void {
        $id = $this->requireId($id);

        if (!$this->model->find($id)) {
            Response::json(404, false, 'Data tidak ditemukan');
        }

        $this->model->delete($id);
        Response::json(200, true, 'Data berhasil dihapus');
    }

    /**
     * Validasi input.
     *  - 400 Bad Request          : field wajib tidak diisi
     *  - 422 Unprocessable Entity : data lengkap tetapi gagal validasi (format NIM, panjang, email)
     */
    private function clean(array $input): array {
        $data = [
            'nim'   => $this->str($input, 'nim'),
            'nama'  => $this->str($input, 'nama'),
            'email' => $this->str($input, 'email'),
            'prodi' => $this->str($input, 'prodi'),
        ];

        // Tahap 1: field wajib -> 400
        $missing = [];
        foreach (['nim', 'nama', 'prodi'] as $field) {
            if ($data[$field] === '') {
                $missing[$field] = "Field $field wajib diisi";
            }
        }
        if ($missing) {
            Response::json(400, false, 'Field nim, nama, dan prodi wajib diisi', null, $missing);
        }

        // Tahap 2: aturan validasi -> 422 (semua kesalahan dikumpulkan per field)
        $errors = [];
        if (!ctype_digit($data['nim']) || strlen($data['nim']) !== self::NIM_LENGTH) {
            $errors['nim'] = 'Format NIM tidak valid, harus ' . self::NIM_LENGTH . ' digit angka';
        }
        if ($this->len($data['nama']) > 100) {
            $errors['nama'] = 'Nama maksimal 100 karakter';
        }
        if ($this->len($data['prodi']) > 50) {
            $errors['prodi'] = 'Prodi maksimal 50 karakter';
        }

        if ($data['email'] !== '') {
            if (!filter_var($data['email'], FILTER_VALIDATE_EMAIL) || $this->len($data['email']) > 100) {
                $errors['email'] = 'Format email tidak valid';
            }
        } else {
            $data['email'] = null;
        }

        if ($errors) {
            Response::json(422, false, 'Validasi data gagal', null, $errors);
        }

        return $data;
    }
}
