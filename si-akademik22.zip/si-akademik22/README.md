# Acara 18-20 — JSON, Postman, Autentikasi JWT dan Error Handling (PHP Native, MVC)

## Cara menjalankan
1. Letakkan folder `sistem-informasi-akademik` di `htdocs` (XAMPP) atau `www` (Laragon). Aktifkan Apache + MySQL, dan pastikan `mod_rewrite` aktif.
2. Buka phpMyAdmin, lalu import `database/db_workshop.sql`.
3. Uji di Postman dengan alamat dasar:
   `http://localhost/sistem-informasi-akademik/public`
   (sesuaikan jika folder berada di subfolder lain, misalnya `/BKPM/sistem-informasi-akademik/public`)

## Alur
Client → `public/index.php` (Front Controller) → `Router` → `Controller` → `Model` → MySQL → `Response::json()` → JSON

## Dokumentasi endpoint

### Mahasiswa — `/mahasiswa`
| Method | Alamat | Body (JSON) | Response sukses | Response gagal |
|---|---|---|---|---|
| GET | `/mahasiswa` | - | 200, `data` berisi semua mahasiswa | - |
| GET | `/mahasiswa?id=1` | - | 200, `data` satu mahasiswa | 404 tidak ditemukan, 400 ID tidak valid |
| POST | `/mahasiswa` | `{"nim":"220100123","nama":"Andi Saputra","prodi":"Teknik Informatika"}` | 201, `data.id` | 400 JSON salah / body kosong, 422 field kosong / format NIM (harus 9 digit) / panjang / email, 409 NIM duplikat |
| PUT | `/mahasiswa?id=1` | sama seperti POST | 200 berhasil diperbarui | 400, 404, 422, 409 NIM dipakai mahasiswa lain |
| DELETE | `/mahasiswa?id=1` | - | 200 berhasil dihapus | 400, 404 |

### Buku — `/buku`
| Method | Alamat | Body (JSON) | Response sukses |
|---|---|---|---|
| GET | `/buku`, `/buku?id=1` | - | 200 |
| POST | `/buku` | `{"judul":"Pemrograman Web","penulis":"Ahmad","tahun_terbit":2024}` | 201 (400 field kosong, 422 validasi gagal) |
| PUT | `/buku?id=1` | sama seperti POST | 200 |
| DELETE | `/buku?id=1` | - | 200 |

`tahun_terbit` boleh dikosongkan. ID juga bisa dikirim lewat path, misalnya `/mahasiswa/1`.

### Register — `/register` (Acara 19)
Jalankan `database/users.sql` di phpMyAdmin (database `workshop`) terlebih dahulu.

| Method | Alamat | Body (JSON) | Response sukses | Response gagal |
|---|---|---|---|---|
| POST | `/register` | `{"username":"andi","email":"andi@mail.com","password":"rahasia123"}` | 201, `data.id` | 400 body kosong / JSON salah, 422 field kosong / email tidak valid, 409 username atau email sudah dipakai, 405 selain POST |

Kata sandi disimpan dengan `password_hash()` (PASSWORD_DEFAULT) dan tidak pernah dikirim kembali ke client. `login()` ditambahkan pada Acara 20.

### Login — `/login` (Acara 20)
| Method | Alamat | Body (JSON) | Response sukses | Response gagal |
|---|---|---|---|---|
| POST | `/login` | `{"username":"andi","password":"rahasia123"}` | 200, `data.token`, `data.role`, `data.expires_in` (300 detik) | 400 field kosong / JSON salah, 401 username atau password salah, 405 selain POST |

Token berupa JWT (HS256) buatan sendiri di `app/core/Auth.php`, berlaku 5 menit. Kirim pada request berikutnya dengan header `Authorization: Bearer <token>`.

### Endpoint yang dilindungi token
`POST`, `PUT`, dan `DELETE` pada `/mahasiswa` memanggil `Auth::requireAuth()`. Tanpa token atau dengan token salah/kedaluwarsa, response 401 (`Token tidak ditemukan` atau `Token tidak valid atau kedaluwarsa`). `GET` tetap publik.

### Format response (envelope seragam)
Semua response — dari Router, Controller, maupun Database — dikirim lewat `Response::json()`.

```json
{ "success": true,  "message": "Data berhasil ditambahkan", "data": { "id": 1 }, "timestamp": "2026-10-24T16:00:37+00:00" }
{ "success": false, "message": "NIM sudah terdaftar", "data": null, "timestamp": "2026-10-24T16:00:37+00:00" }
{ "success": false, "message": "Validasi data gagal", "data": null,
  "errors": { "nim": "Format NIM tidak valid, harus 9 digit angka" }, "timestamp": "2026-10-24T16:00:37+00:00" }
```
Field `errors` hanya muncul pada kegagalan validasi (422).

### Kode status yang dipakai
| Kode | Dipakai untuk |
|---|---|
| 200 | GET / PUT / DELETE berhasil |
| 201 | POST berhasil membuat data |
| 400 | Body kosong, JSON rusak, ID tidak valid |
| 401 | Token tidak ada, tidak valid, atau kedaluwarsa; login gagal |
| 404 | Data atau endpoint tidak ditemukan |
| 405 | Method HTTP tidak diizinkan |
| 409 | Konflik data (NIM duplikat) |
| 422 | Field wajib kosong atau gagal validasi (format NIM, panjang, email, tahun_terbit) |
| 500 | Kegagalan server / koneksi database |

### Mode pengembangan
`app/config/app.php` berisi konstanta `APP_ENV`. Nilai `development` membuat JSON dicetak rapi (`JSON_PRETTY_PRINT`), nilai `production` membuat JSON ringkas.

## Struktur
```
app/config/Database.php        Koneksi PDO (Singleton)
app/core/autoload.php          Autoloader (spl_autoload_register)
app/core/Router.php            Memetakan URL + method HTTP ke Controller
app/core/Response.php          Response::json() — envelope JSON + kode status HTTP
app/core/Auth.php              Token JWT (generate, validasi) dan middleware requireAuth()
app/core/BaseController.php    Helper baca body JSON, validasi ID, utilitas string
app/config/app.php             Konstanta APP_ENV (development / production)
app/models/Mahasiswa.php       Query tabel mahasiswa + validasi NIM duplikat
app/models/Buku.php            Query tabel buku (Tugas Mandiri 1)
app/models/User.php            Query tabel users + validasi email (Acara 19)
app/controllers/AuthController.php  register() (Acara 19)
app/controllers/...            Logika endpoint
public/index.php, .htaccess    Front Controller
database/db_workshop.sql       Skrip database
database/users.sql             Tabel users (Acara 19)
```

## Dokumentasi OpenAPI (Acara 22)
Spesifikasi OpenAPI 3.0 ada di `docs/openapi.yaml`. Tempel isinya ke https://editor.swagger.io untuk melihat pratinjau, lalu simpan tangkapan layar di folder `docs/`.
